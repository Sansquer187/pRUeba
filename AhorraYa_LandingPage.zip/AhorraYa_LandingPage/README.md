# AhorraYa - Landing Page

## Descripción del Proyecto
AhorraYa es una aplicación innovadora para la gestión financiera personal. Con una interfaz intuitiva y herramientas avanzadas de IA, permite a los usuarios controlar sus finanzas, establecer metas de ahorro y recibir recomendaciones personalizadas.

## Autores
- Coronado Gonzales Kevin Rene
- Diaz Culqui Fabrizio David
- Ibarra Parravicini Enrique Valentino
- Marquez Guillen Joan Enric
- Silva Carbajal Iván Santiago

## Segmento Objetivo
Nuestro público incluye personas de 18 años en adelante que desean gestionar mejor sus finanzas y alcanzar metas financieras a largo plazo.

## Principales Características
- Gestión automática de ahorros
- Recomendaciones personalizadas
- Análisis de gastos
- Metas financieras específicas
